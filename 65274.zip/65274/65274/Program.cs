﻿using System;

class Sklep
{
    private string adres;
    private int iloscTowarow;

    public Sklep(string adres, int iloscTowarow)
    {
        this.adres = adres;
        this.iloscTowarow = iloscTowarow;
    }

    public string Info()
    {
        return $"{adres};{iloscTowarow}";
    }
}

class Supermarket : Sklep
{
    private string siec;

    public Supermarket(string adres, int iloscTowarow, string siec) : base(adres, iloscTowarow)
    {
        this.siec = siec;
    }

    public string Promocja(int parametr)
    {
        if (parametr % 3 == 0)
        {
            return "Promocja 30%";
        }
        else
        {
            return "Brak promocji";
        }
    }
}

class SklepMeblowy : Sklep
{
    private char klas;

    public SklepMeblowy(string adres, int iloscTowarow, char klas) : base(adres, iloscTowarow)
    {
        this.klas = klas;
    }

    public bool Dostepnosc(int idProduktu)
    {
        return idProduktu >= 0 && idProduktu <= 14;
    }
}

class Program
{
    static void Main(string[] args)
    {
        // Tworzenie obiektów
        Sklep sklep1 = new Sklep("Ul. Kwiatowa 12", 120);
        Sklep sklep2 = new Sklep("Ul. Słoneczna 5", 80);

        Supermarket supermarket1 = new Supermarket("Ul. Ogrodowa 3", 200, "Biedronka");
        Supermarket supermarket2 = new Supermarket("Ul. Leśna 8", 150, "Lidl");

        SklepMeblowy sklepMeblowy1 = new SklepMeblowy("Ul. Morska 11", 40, 'A');
        SklepMeblowy sklepMeblowy2 = new SklepMeblowy("Ul. Górska 22", 30, 'B');

        // Wywołanie metod Promocja i Dostepnosc
        Console.WriteLine(supermarket1.Promocja(3));
        Console.WriteLine(supermarket2.Promocja(2));

        Console.WriteLine(sklepMeblowy1.Dostepnosc(5));
        Console.WriteLine(sklepMeblowy2.Dostepnosc(15));

        // Wyświetlenie informacji o wszystkich sklepach
        Console.WriteLine(sklep1.Info());
        Console.WriteLine(sklep2.Info());

        Console.WriteLine(supermarket1.Info());
        Console.WriteLine(supermarket2.Info());

        Console.WriteLine(sklepMeblowy1.Info());
        Console.WriteLine(sklepMeblowy2.Info());
    }
}